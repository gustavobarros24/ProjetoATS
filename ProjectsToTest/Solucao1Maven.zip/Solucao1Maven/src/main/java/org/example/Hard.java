package org.example;


/**
 * Interface Hard
 *
 * GrupoTP-10
 * --
 */
public interface Hard
{
    double getFatorHard ();
}
